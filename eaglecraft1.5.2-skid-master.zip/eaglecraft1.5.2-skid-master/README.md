# eaglecraft1.5.2-unblocked
omg
Eaglecraft is already on github just not on pages so I put it on pages because some people might not know how to download it.
